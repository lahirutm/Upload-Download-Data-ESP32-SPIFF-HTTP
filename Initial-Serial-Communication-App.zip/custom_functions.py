import os
import sys
import json
import string
from serial.tools.list_ports import comports

from usb_database import USB_IDS

GOOD_CHARS = ''.join(
    [i for i in string.printable if i not in "*\t\n\r\x0b\x0c"])


def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)


def get_port_name(vid, pid):
    name = 'Unknown'
    try:
        val = USB_IDS[vid]
        name = val['name']
        name = val['data'][pid]
    except:
        pass
    return name


def get_ports():
    """ Return Detected Ports """
    ports = []
    for port in comports():
        description = port.description.lower()
        if description != 'n/a':
            try:
                vid = f"{port.vid:4x}"
            except:
                vid = "0000"
            try:
                pid = f"{port.pid:4x}"
            except:
                pid = "0000"
            name = get_port_name(vid, pid)
            if name == 'Unknown':
                if port.product != None:
                    if port.product.strip() != '':
                        name = port.product
                    else:
                        name = port.description
                else:
                    name = port.description

            ports.append({
                "product": name,
                "device": port.device})
    return ports


def dump_json(path, data):
    with open(path, 'w') as f:
        f.write(json.dumps(data, indent=4))


def load_json(path):
    with open(path, 'r') as f:
        return json.loads(f.read())


def write_text(ser,  addr, size, text):
    size -= 1
    text = [ord(i) for i in text if i in GOOD_CHARS]
    if len(text) < size:
        text += [0] * (size - len(text))  # Add Padding to text
    if len(text) > size:
        text = text[:size].copy()
    text += [0]
    for i in range(size):
        ser.update(addr + i, text[i])


def read_text(ser,  addr, size):
    size -= 1
    text = []
    for i in range(size):
        c = ser.get(addr + i)
        text.append(chr(c))
    text = [i for i in text if i in GOOD_CHARS]
    if len(text) > size:
        text = text[:size].copy()
    return ''.join(text)


if __name__ == '__main__':
    print(get_ports())
