import os
import sys
import time

from PyQt5 import QtGui
from PyQt5 import QtCore
from PyQt5 import QtWidgets


# Local functions and classes
from get_data import SerialData
from custom_functions import (
    read_text,
    write_text
)


class Connecter(QtCore.QObject):
    finished = QtCore.pyqtSignal(bool)

    def __init__(self, connect_state, port, parent=None):
        super().__init__(parent)
        self.port = port
        self.connect_state = connect_state

    def run(self):
        result = False
        if self.port:
            with SerialData(port=self.port) as ser:
                if not self.connect_state:
                    response = ser.connect()
                    if response:
                        result = True
                else:
                    ser.disconnect()
        self.finished.emit(result)


class Communication(QtCore.QObject):
    finished = QtCore.pyqtSignal(list)

    def __init__(self, data, mode, connect_state, port, label_size=10, debug=True, parent=None):
        super().__init__(parent)
        self.port = port
        self.data = data
        self.mode = mode
        self.label_size = label_size
        self.debug = debug
        self.connect_state = connect_state

    def read_data(self, ser: SerialData):
        def read_it(btn):
            for e in btn:
                    if self.debug:
                        print(f"Addr: {e['addr']}")
                    if 'label' in e['name']:
                        e['value'] = read_text(ser, e['addr'], self.label_size)
                    else:
                        e['value'] = ser.get(e['addr'])

        for page in self.data[:-1]:
            for btn in page:
                read_it(btn)
        read_it(self.data[-1])
                

    def write_data(self, ser: SerialData):
        def write_it(btn):
            for e in btn:
                    if self.debug:
                        print(f"Addr: {e['addr']}")
                    if 'label' in e['name']:
                        write_text(
                            ser,
                            e['addr'],
                            self.label_size,
                            e['value'])
                    else:
                        ser.update(e['addr'], e['value'])
        for page in self.data[:-1]:
            for btn in page:
                write_it(btn)
        write_it(self.data[-1])
                

    def run(self):
        if self.port and self.connect_state:
            with SerialData(port=self.port) as ser:
                if self.mode == 'read':
                    self.read_data(ser)
                else:
                    self.write_data(ser)
        self.finished.emit(self.data)
