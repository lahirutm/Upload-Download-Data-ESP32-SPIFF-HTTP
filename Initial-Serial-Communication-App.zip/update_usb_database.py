import json

# Store as backup only NO NEED 
# http://www.linux-usb.org/usb.ids

def get_id(text):
    text = text.strip().split()
    value = text[0]
    text = ' '.join(text[1:])
    return [value, text]


data = {}
in_check = False
out_check = False

info = [""]
with open('raw.txt') as f:
    for i, line in enumerate(f):
        if len(line.split()) > 1:
            print(f"{i+1}", end="\r")
            if line.startswith('\t'):
                if not in_check:
                    new_data = {}
                    in_check = True
                res = get_id(line)
                new_data[res[0]] = res[1]
            else:
                if in_check:
                    data[value]['data'] = new_data
                    in_check = False
                info = get_id(line)
                value = info[0]
                data[value] = {}
                data[value]['name'] = info[1]
                data[value]['data'] = {}

    if in_check:
        data[value]['data'] = new_data

with open('output.json', 'w') as f:
    f.write(json.dumps(data, indent=2))
print("")
